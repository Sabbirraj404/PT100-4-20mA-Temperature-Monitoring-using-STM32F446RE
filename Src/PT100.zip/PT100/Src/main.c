#include <stdint.h>
#include <stdio.h>

#define RCC_AHB1ENR   (*(volatile uint32_t*)0x40023830)
#define RCC_APB1ENR   (*(volatile uint32_t*)0x40023840)
#define RCC_APB2ENR   (*(volatile uint32_t*)0x40023844)

#define GPIOA_MODER   (*(volatile uint32_t*)0x40020000)
#define GPIOA_AFRL    (*(volatile uint32_t*)0x40020020)

#define USART2_SR     (*(volatile uint32_t*)0x40004400)
#define USART2_DR     (*(volatile uint32_t*)0x40004404)
#define USART2_BRR    (*(volatile uint32_t*)0x40004408)
#define USART2_CR1    (*(volatile uint32_t*)0x4000440C)

#define ADC1_SR       (*(volatile uint32_t*)0x40012000)
#define ADC1_CR2      (*(volatile uint32_t*)0x40012008)
#define ADC1_SQR3     (*(volatile uint32_t*)0x40012034)
#define ADC1_DR       (*(volatile uint32_t*)0x4001204C)

void delay()
{
    for(volatile int i=0;i<200000;i++);
}

void UART_Init()
{
    RCC_AHB1ENR |= (1<<0);
    RCC_APB1ENR |= (1<<17);

    GPIOA_MODER &= ~(3<<4);
    GPIOA_MODER |= (2<<4);

    GPIOA_AFRL |= (7<<8);

    USART2_BRR = 0x0683;
    USART2_CR1 |= (1<<3);
    USART2_CR1 |= (1<<13);
}

void UART_SendChar(char c)
{
    while(!(USART2_SR & (1<<7)));
    USART2_DR = c;
}

void UART_SendString(char *str)
{
    while(*str)
    {
        UART_SendChar(*str++);
    }
}

void ADC_Init()
{
    RCC_AHB1ENR |= (1<<0);
    RCC_APB2ENR |= (1<<8);

    GPIOA_MODER |= (3<<0);

    ADC1_SQR3 = 0;
    ADC1_CR2 |= (1<<0);
}

uint16_t ADC_Read()
{
    ADC1_CR2 |= (1<<30);
    while(!(ADC1_SR & (1<<1)));
    return ADC1_DR;
}

int main()
{
    UART_Init();
    ADC_Init();

    float voltage, current, temp;
    uint16_t adc;
    char buffer[50];

    while(1)
    {
        adc = ADC_Read();

        voltage = (adc * 3.3f) / 4095.0f;

        if(voltage > 3.3f)
            voltage = 3.3f;

        current = voltage / 220.0f;
        current = current * 1000.0f;

        if(current > 15.0f)
            current = 15.0f;

        temp = ((current - 4.0f) / 16.0f) * 100.0f;

        if(temp < 0) temp = 0;

        sprintf(buffer, "Temp: %.2f C\r\n", temp);
        UART_SendString(buffer);

        delay();
    }
}
